Instructions on how to run Twitter feeds application
-----------------------------------------------------
1) Create folder named "twitterFeed" under your c drive(C:)
2) Copy both user.txt and tweet.txt into twitterFeed folder under c drive
3) Run setup 

Installation complete