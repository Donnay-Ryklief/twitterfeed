﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TwitterFeed
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaired all file paths and variables to be added to txt files
            string twittername;
            string followername;
            string filepath = @"C:\twitterFeed\user.txt";
            string newsfeedpath = @"C:\twitterFeed\tweet.txt";
            string line;

            /* If statement checks if file does exist if yes it will then read the file that was given in the file path and output
             * All content in text file User
             */
            if (File.Exists(filepath))
            {
                StreamReader file = null;
                try
                {
                    file = new StreamReader(filepath);
                    while ((line = file.ReadLine()) != null)
                    {
                        Console.WriteLine(line);

                    }

                }
                finally
                {
                    if (file != null)
                    file.Close();
                }

                //Request user input that which will be added to user file
                Console.WriteLine("");
                Console.WriteLine("Enter your name");
                twittername = Console.ReadLine();
                Console.WriteLine("Enter name who you want to follow @");
                followername = Console.ReadLine();

                // Declaired strinbuilder to add content to the user.text file
                StringBuilder usertxt = new StringBuilder();

                usertxt.AppendLine("");
                usertxt.Append(twittername + " Follows " + followername);
                string userpath = @"C:\twitterFeed\user.txt";
                File.AppendAllText(userpath, usertxt.ToString());

               
                Console.WriteLine("");
                Console.WriteLine("Users and Followrs");
                Console.WriteLine("");

                //Displays data in user.txt and new data that was added
                if (File.Exists(filepath))
                {
                    StreamReader file3 = null;
                    try
                    {
                        file3 = new StreamReader(filepath);
                        while ((line = file3.ReadLine()) != null)
                        {
                            Console.WriteLine(line);

                        }

                    }
                    finally
                    {
                        if (file != null)
                        file.Close();
                    }

                    //Displays news feeds in tweet.txt file
                    Console.WriteLine("");
                    Console.WriteLine("Users newsFeeds");
                    Console.WriteLine("");
                    if (File.Exists(newsfeedpath))
                    {
                        StreamReader file2 = null;
                        try
                        {
                            file2 = new StreamReader(newsfeedpath);
                            while ((line = file2.ReadLine()) != null)
                            {
                                Console.WriteLine(line);

                            }

                        }
                        finally
                        {
                            if (file != null)
                            file.Close();
                        }

                        Console.ReadLine();
                    }
                }
            }
        }
    }
}
